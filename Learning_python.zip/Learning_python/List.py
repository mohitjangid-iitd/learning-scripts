Udaigiri=["""names as strings"""]
Girnar=["""names as strings"""]
Shivalik=["""names as strings"""]
Nalanda=["""names as strings"""]
Day=["""names as strings"""]
All=Udaigiri+Girnar+Shivalik+Nalanda+Day

# print(len(All))

# print(type(All))

# print(len(Udaigiri),len(Girnar),len(Shivalik),len(Nalanda),len(Day))

# print(Udaigiri)

# print([len(p) for p in Udaigiri])

# print([p for p in Udaigiri if len(p)==5])

# a=Udaigiri.count('Example')
# print(a)

# b=Udaigiri.index('Example')
# print(b)

# Night=Day.copy()
# Night[2]='Tito'
# print(Night,Day)


# if 'Example' in Udaigiri:
#     print('han h')

# print(Udaigiri[0:16:2])

# Shivalik.append('Example')
# print(Shivalik,len(Shivalik),len(All)) #All didn't change
# All=Udaigiri+Girnar+Shivalik+Nalanda+Day
# print(len(All))

# Change=tuple(All)
# print(type(All))

# r=All.count('A' in [i for i in All]) #do not work
# print([i for i in Udaigiri],r)

# p=input('Type your name:').upper()

# if p in Udaigiri:
#     print('Udaigiri ka londa')
# elif p in Girnar:
#     print('Girnar ka gunda')
# elif p in Shivalik:
#     print('Shivalik se h ye to')
# elif p in Nalanda:
#     print('Hostal nahi in ka to flate h')
# elif p in Day:
#     print('Ye to bahar se ata h')
# else:
#     print('Tu kon h?')