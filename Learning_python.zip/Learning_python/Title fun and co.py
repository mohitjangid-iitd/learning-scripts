#a=input('Write=')
#print(len(a))

#Index

b='Vishwakarma and Shubhanshu'
c='noThiNg12somTHing'
d='vishwakarma and shubhanshu'
print(b[0:26:2])

# string operators

# print(b.upper())
# print(b.lower())
# print(b.rstrip("u"))
# print(b.replace("Vishwakarma","Sezal"))
# print(b.split('a')) #convert into list
# print(c.capitalize())
# print(b.center(47))
# print(b.count('sh'))
# print(b.endswith('shu')) #startswith
# print(b.endswith('sh'))
# print(b.find('an'))
# print(b.find('z'))
# print(b.index('an')) #same as find
# #print(b.index('z')) #but gives error when not found
# print(c.isalnum())
# print(c.isalpha())
# print(b.islower()) #isupper
# print(d.islower())
# print(c.swapcase())
# print(d.title()) #istitle
# print(input('Input:').capitalize())